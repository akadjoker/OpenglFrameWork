Male african head example (c) 2007. Vidar Rapp
http://vidarrapp.se/

=====================================================

From: Vidar Rapp <vidar.rapp@gmail.com>
To: Dmitry Sokolov <dmitry.sokolov@loria.fr>
Subject: Re: african head model
Date: Sat, 10 Dec 2011 22:59:48 +0100

Hey Dmitry,

Please feel free to use the model (specified below) as an example in
your renderer.

I hope you get a lot of use out of it.

All the best,
Vidar

