/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sample_1.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lrosa-do <lrosa-do@student.42lisboa>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/15 16:14:07 by lrosa-do          #+#    #+#             */
/*   Updated: 2023/02/17 16:02:34 by lrosa-do         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "glad.h"

#include "../pch.hpp"
#include "../utils.hpp"
#include "../render.hpp"
#include "../math.hpp"
#include "../camera.hpp"
#include "../core.hpp"
  
  
const int screenWidth = 1280;
const int screenHeight = 720;


int GetRandomValue(int min, int max)
{
    if (min > max)
    {
        int tmp = max;
        max = min;
        min = tmp;
    }  

    return (rand()%(abs(max - min) + 1) + min);
}
   
int run_sample()   
{ 
App app;
app.CreateWindow(screenWidth, screenHeight, "Vertex Texture Colored",false);

//Shader shader=Shader::createSolidColor();
Shader shader=Shader::createColorAmbient();
  
//Shader shader=Shader::createSolidColorTexture();

Camera camera; 
camera.SetPosition(0, 1, 10);  

Texture2D texture;//(64,64);
texture.Load("assets/cube.png");

Texture2D texture_floor;//(64,64);
texture_floor.Load("assets/grass_1024.jpg");

Texture2D text_mesh;//(64,64);
text_mesh.Load("assets/african_head_diffuse.tga",true);



Mesh *plane=Mesh::CreateHills(Color(1,1,1),Vec2(5,5),10,10,0.2,Vec2(5,5),Vec2(8,8));
//Mesh::CreatePlane(50,50,Color(0.5f,0.5f,0.5f));

Mesh *cube= Mesh::CreateCube(1,1.5,1,Color(1,0,1));

Mesh *sphere = Mesh::CreateSphere(Color(1,0,0));

Mesh *cilinder = Mesh::CreateCylinder(Color(1,1,1));

Mesh *cone = Mesh::CreateCone(Color(1,1,0));

Mesh *torus = Mesh::CreateTorus(Color(1,1,0),0.2f,1.0f);

Mesh *mesh = Mesh::LoadMesh("assets/african_head.h3d");

 
//sphere.CreateSphere(1,32,32,Color(1,1,0));


  
 
   Mat4 projection = Mat4::ProjectionMatrix(45.0f,  static_cast<float>(screenWidth) / screenHeight, 0.1f, 1000.0f);
    

   glClearColor(0.1,0.1,0.3f,1.0);
   glEnable(GL_DEPTH_TEST);  
   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);  



int frameCount = 0;
Uint32 startTime = SDL_GetTicks();


  

  while (!app.ShouldClose()) 
  {
       
       float deltaTime =  app.GetFrameTime();
        
 

        const Uint8 *keys = SDL_GetKeyboardState(NULL);

         if(keys[SDL_SCANCODE_W])
            camera.ProcessKeyboard(FORWARD, deltaTime);
        else if(keys[SDL_SCANCODE_S])
           camera.ProcessKeyboard(BACKWARD, deltaTime);
  
        if(keys[SDL_SCANCODE_A])
             camera.ProcessKeyboard(LEFT, deltaTime);
        else if(keys[SDL_SCANCODE_D])
             camera.ProcessKeyboard(RIGHT, deltaTime);
           
         
        int MouseX,MouseY;
        
        Uint32 button = SDL_GetRelativeMouseState(&MouseX, &MouseY);
        if (button & SDL_BUTTON(SDL_BUTTON_LEFT)) 
        {
            camera.ProcessMouseMovement(MouseX, -MouseY);
        } 
 
 
             
       
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
       

        Mat4 view =camera.GetViewMatrix();
  
  
      texture_floor.Bind(0);
      
       
       shader.Bind();
       shader.setMatrix4("view", view);
       shader.setMatrix4("projection" ,projection);
       shader.setVector3("viewPos" ,camera.Position);
       

        Mat4 model= Mat4::Identity();
        shader.setMatrix4("model", model);
        plane->Render();

             texture.Bind(0);
		 
        model= Mat4::Translate(-1,1,0);
        shader.setMatrix4("model", model);
        cube->Render();
		 
 

        model= Mat4::Translate(1,1,0);
        shader.setMatrix4("model", model);
        sphere->Render();
		 
        model= Mat4::Translate(3,1,0);
        shader.setMatrix4("model", model);
        cilinder->Render();

        model= Mat4::Translate(-3,1,0);
        shader.setMatrix4("model", model);
        cone->Render();


        model= Mat4::Translate(-5,1,0);
        shader.setMatrix4("model", model);
        torus->Render();
        


        text_mesh.Bind(0);
        model= Mat4::Translate(0,1,5);
        shader.setMatrix4("model", model);
        mesh->Render();
        
        
        app.Swap();



         frameCount++;
        if (SDL_GetTicks() - startTime >= 1000)
        {
            char title[150];

                snprintf(title, sizeof( title), "  FPS: %d", frameCount);

            SDL_SetWindowTitle(app.getWindow(), title);
            frameCount = 0;
            startTime = SDL_GetTicks();
        }
  } 
 
 delete plane;
 delete cube;
 delete sphere;
 delete cilinder;
 delete cone;
 delete torus;
delete mesh;

  std::cout<<"Exit"<<std::endl;
  return 0;
}