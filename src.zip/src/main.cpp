/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lrosa-do <lrosa-do@student.42lisboa>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/12 13:51:30 by lrosa-do          #+#    #+#             */
/*   Updated: 2023/02/17 14:26:59 by lrosa-do         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

                            
#include "samples/sample_1.hpp"     
      
extern int run_sample() ;         



            
int main() 
{ 
  run_sample() ;
 
  return 0;     
}                          

// #include "glad.h"

// #include "pch.hpp"
// #include "utils.hpp"
// #include "render.hpp"
// #include "math.hpp"
// #include "camera.hpp"
// #include "core.hpp"
  